import React from 'react'

import style from './header.css'

const Header = () => (
  <header className={style.header}>
    <div>
      Topo
    </div>
  </header>
);

export default Header;