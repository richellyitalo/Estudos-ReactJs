import React from 'react'

const Home = () => {
  return (
    <h1>Home - Início</h1>
  )
}

export default Home